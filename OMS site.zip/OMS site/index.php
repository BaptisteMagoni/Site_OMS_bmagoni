<?php
  session_start();

  include_once('data_base.php');

  $galerie = $bdd->query('SELECT * FROM galeries');

  include_once('connexion_php.php');

?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>OMS Site - Baptiste MAGONI</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/thumbnail-gallery.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/index.css">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
      <a class="navbar-brand" href="index.php">Galerie</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              
            </li>
          </ul>
          <div class="dropdown" style="text-align: center;">
              <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size: 16px;">
              Connexion/Inscription</button>
              <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                <form method="POST" action="">
                  <p style="text-align: center; font-size: 12px;">Connexion</p>
                  <hr width="75%" color="gray">
                  <div class="input-group mb-3" >
                    <div class="input-group-prepend">
                     <input type="text" name="users" placeholder="Utilisateur" style="margin-left: 8px; margin-right: 8px; text-align: center;" />
                    </div>
                  </div>
                  <div class="input-group mb-3" >
                    <div class="input-group-prepend">
                     <input type="password" name="password" placeholder="Mot de passe" style="margin-left: 8px; margin-right: 8px; text-align: center;" />
                    </div>
                  </div>
                  <input type="submit" name="connexion" value="Connexion" style="margin-right: 50px; margin-left: 50px;">
                  <hr width="75%" color="gray">
                  <p style="text-align: center;"><li><a href="#" style="text-align: center; margin-left: 70px; margin-right: 70px; font-size: 12px;">Inscription</a></li></p>
                </form>
              </div>
            </div>
        </div>
      </div>
    </nav>
    <!-- Page Content -->
    <div class="container">
    <h1 class="my-4 text-center text-lg-left" style="text-align: center;">Galerie photo</h1>
      <?php 
      while($m = $galerie->fetch()) { 
          $gp = array($m);

          $req_img = $bdd->query('SELECT COUNT(id) FROM photos WHERE galerie_id='.$m['id']);
          $result = $req_img->fetch();
          $count = $result[0];
      ?>
      <div class="jumbotron" style="border: 1px solid gray;">
        <img src="<?= $m['miniature']; ?>" style="float: right; width: 300px; height: 200px; margin-left: 20px; margin-bottom: 20px;" />
        <h1 class="display-4"><?= $m['title']; ?></h1>
        <p class="lead"><?= $m['description']; ?></p>
        <hr class="my-4">
        <p>Galerie ajoutée le <?= $m['date_mel']; ?></p>
        <p>Dernière mise à jour le <?= $m['date_maj'] ?></p>
        <p><?php if($count == 0 OR $count == 1) { echo "Il y a ".$count." image dans la galerie"; }else{ echo "Il y a ".$count." images dans la galerie"; } ?></p>
        <a class="btn btn-primary btn-lg" href="photo.php?page=photo&id_album=<?= $m['id'] ?>" role="button">Voir la galerie</a>
      </div>
      <?php } ?>
    </div>
    

    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
