<?php
  session_start();
    include_once('data_base.php');
    include_once('upload.php');

    $galerie = $bdd->query("SELECT * FROM galeries");

    $adresse = "http://".$_SERVER['SERVER_NAME'].":".$_SERVER['SERVER_PORT'].$_SERVER["REQUEST_URI"];
    $_SESSION['adresse'] = $adresse;

    $id_album = '';

    if(isset($_GET['id_album'])){
      $id_album  = (int) $_GET['id_album'];
      $req_name_album = $bdd->query("SELECT `title` FROM `galeries` WHERE `id` = ".$id_album);
      $result = $req_name_album->fetch();
      $name_album = $result[0];
    }

    if($id_album != "ajouter_photo"){
      $requete_photo = $bdd->query("SELECT galeries.id, photos.path, photos.id as id_photo FROM galeries LEFT JOIN photos ON galeries.id = photos.galerie_id WHERE galeries.id = ".$id_album);
    }

    if(isset($_GET['id_photo'])){
      $id = (int) $_GET['id_photo'];
      $req_supr_photo = $bdd->query("DELETE FROM photos WHERE id=".$id);
      $list = array();
      $list = explode("&", $adresse);
      header("Location: ".$list[0]."&".$list[1]."&".$list[2]);
    }

    if(isset($_POST['save'])){

      $comment = htmlspecialchars($_POST['Commentaire']);

      $insert_photos = $bdd->prepare("INSERT INTO photos(`path`, comment, galerie_id) VALUES (?, ?, ?)");
      $insert_photos->execute(array($path, $comment, $id_album));
      $insert_galerie = $bdd->prepare("UPDATE galeries SET date_maj = ? WHERE id = ?");
      $date_maj = date("Y-m-d H:i:s");
      $insert_galerie->execute(array($date_maj, $id_album));
      header('Location: '.$adresse);
    }

    $req_img = $bdd->prepare('SELECT COUNT(id) FROM photos WHERE galerie_id = ?');
    $req_img->execute(array($id_album));
    $result = $req_img->fetch();
    $count = $result[0];
?>
<!DOCTYPE html>
<html lang="fr">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>OMS Site - Baptiste MAGONI</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/thumbnail-gallery.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/index.css">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Start Bootstrap</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Galerie</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="creer_galerie.php?id_user=<?= $_SESSION['userinfo']['id'] ?>">Galerie admin</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="photo_admin.php?page=photo_admin&id=no">Photo admin
                <span class="sr-only">(current)</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container" style="margin-top: 20px;">
        <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="margin-bottom: 30px;">Choix Galerie</button>
        <form method="POST" enctype="multipart/form-data">
          <div class="dropdown-menu">
            <?php 
            while($m = $galerie->fetch()){
              $gp = array($m);
            ?>
            <a class="dropdown-item" name="title_galerie" href="photo_admin.php?id_user=<?=$_SESSION['userinfo']['id']?>&page=photo_admin&id_album=<?= $m['id'] ?>"><?= $m['title'] ?></a>
            <?php
            }
            ?>
          </div>
        <label>Album choisi : <?php if($id_album != '') { echo $name_album; } ?></label>
          <div class="input-group">
            <div class="custom-file">
              <input type="file" name="file" value="Choisir une image"/>
            </div>
          </div>
          <div class="form-group" style="margin-top: 20px; margin-bottom: 20px">
            <label for="exampleFormControlInput1">Commentaire</label>
            <textarea type="text" name="Commentaire" class="form-control" id="exampleFormControlInput1" placeholder="Ex : 6ème à la plage"></textarea>
          </div>
          <div class="input-group mb-3" style="margin-left: 1100px ; margin-top: 100px">
            <div class="input-group-prepend" style="background-color: green;">
             <input type="submit" name="save" value="Enregistrer" style="background-color: green;" />
            </div>
          </div>
          <div class="row text-center text-lg-left">
            <?php
            if($count != 0){
              if($id_album != "no"){
                while($m = $requete_photo->fetch()){
                  $img = array($m);
            ?>
              <div class="col-lg-3 col-md-4 col-xs-6 text-center">
                    <img class="img-fluid img-thumbnail" src="<?= $m['path'] ?>" alt="" style="border: 1px solid gray; width: 250px; height: 200px;">
                    <a class="btn btn-xs btn-danger" href="<?= $adresse.'&id_photo='.$m['id_photo'] ?>">Supprimer</a>
              </div>
            <?php
                }
              }
            }
            ?>
          </div>
        <p id="demo"></p>
      </form>
    </div>

    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
      function click_delete(id){
        <?php //$req = $bdd->query("DELETE FROM `photos` WHERE id = ".id) ?>
      }
    </script>
  </body>

</html>
