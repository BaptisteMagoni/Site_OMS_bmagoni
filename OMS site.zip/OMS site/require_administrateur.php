<?php 
if($_SESSION['userinfo']['permission'] != 1){
	header('Location : index.php');
	//Inclure déconnexion
	die();
}

?>