<?php
session_start();

?>

<!DOCTYPE html>
<html lang="fr">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>OMS Site - Baptiste MAGONI</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/thumbnail-gallery.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/index.css">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Start Bootstrap</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Galerie</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="creer_galerie.php?id_user=<?= $_SESSION['userinfo']['id'] ?>">Galerie admin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="photo_admin.php?id_user=<?= $_SESSION['userinfo']['id'] ?>&page=photo_admin">Photo admin
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- /.container -->
    <div class="container">
    	
    </div>
    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
      function click_delete(id){
        <?php //$req = $bdd->query("DELETE FROM `photos` WHERE id = ".id) ?>
      }
    </script>
  </body>

</html>