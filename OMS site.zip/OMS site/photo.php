<?php
  session_start();

  include_once('data_base.php');
  include_once('connexion_php.php');

  $adresse = "http://".$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
  $_SESSION['adresse'] = $adresse;

  if(isset($_GET['id_album'])){
    $id_album  = (int) $_GET['id_album'];
  }

  $requete_photo = $bdd->query("SELECT galeries.id, photos.path FROM galeries LEFT JOIN photos ON galeries.id = photos.galerie_id WHERE galeries.id = ".$id_album);

  $requete_name_album = $bdd->query("SELECT title FROM galeries WHERE id = ".$id_album);

  $req_count_photo = $bdd->query("SELECT COUNT(`id`) FROM photos WHERE galerie_id = ".$id_album);
  $result = $req_count_photo->fetch();
  $count = $result[0];

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>OMS Site - Baptiste MAGONI</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/thumbnail-gallery.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="css/index.css">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
      <a class="navbar-brand" href="index.php">Galerie</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              
            </li>
          </ul>
          <div class="dropdown" style="text-align: center;">
              <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size: 16px;">
              Connexion/Inscription</button>
              <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                <form method="POST" action="">
                  <p style="text-align: center; font-size: 12px;">Connexion</p>
                  <hr width="75%" color="gray">
                  <div class="input-group mb-3" >
                    <div class="input-group-prepend">
                     <input type="text" name="users" placeholder="Utilisateur" style="margin-left: 8px; margin-right: 8px; text-align: center;" />
                    </div>
                  </div>
                  <div class="input-group mb-3" >
                    <div class="input-group-prepend">
                     <input type="password" name="password" placeholder="Mot de passe" style="margin-left: 8px; margin-right: 8px; text-align: center;" />
                    </div>
                  </div>
                  <input type="submit" name="connexion" value="Connexion" style="margin-right: 50px; margin-left: 50px;">
                  <hr width="75%" color="gray">
                  <p style="text-align: center;"><li><a href="#" style="text-align: center; margin-left: 70px; margin-right: 70px; font-size: 12px;">Inscription</a></li></p>
                </form>
              </div>
            </div>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container">

      <h1 class="my-4 text-center text-lg-left"><?php while($m = $requete_name_album->fetch()){ echo $m['title']; }?></h1>
      <?php 
        if($count != 0){
      ?>
      <div class="row text-center text-lg-left">
        <?php
          while($m = $requete_photo->fetch()){
            $img = array($m);
        ?>
        <div class="col-lg-3 col-md-4 col-xs-6">
            <a href="#" class="d-block mb-4 h-100">
              <img class="img-fluid img-thumbnail" src="<?= $m['path'] ?>" alt="" style="border: 1px solid gray; box-shadow: 10px 5px 5px #C0C0C0; width: 250px; height: 200px;">
            </a>
        </div>
        <?php 
          }
        ?>
      </div>
      <?php 
        }
      ?>
    </div>

    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>

</html>
