<?php
if(!empty($_FILES)){
      $file_name = $_FILES['file']['name'];
      $file_extension = strrchr($file_name, ".");
      $path = "images/".$file_name;

      $file_tmp_name = $_FILES['file']['tmp_name'];
      $file_dest = 'images/'.$file_name;

      $extensions_autorisees = array('.jpg', '.png', '.PNG', '.jpeg');
        if(in_array($file_extension, $extensions_autorisees)){
          if(move_uploaded_file($file_tmp_name, $file_dest)){
            echo "Fichier envoyé avec succès";
          }else{
            echo "Une erreur est survenue lors de l'envoi du fichier";
          }
        }else{
          echo "Seuls les fichiers PDF sont autorisés";
        }
    }
?>