#!/usr/bin python 3.6
#coding: utf-8

import sqlite3

conn = sqlite3.connect('dboms.mwb')
